let img, song, amp;
let x, y, dia, h, a;
let isBlinking = false;
let lastBlinkTime = 0;
let blinkInterval = 500;

function preload() {
  img1 = loadImage(
    "Chinese_Shadow_Play--Precursor_of_Modern_Cinema_8_-_Peoples_Daily-removebg-preview.png"
  );
  img2 = loadImage("Chinese_shadow_play-removebg-preview.png");
  song = loadSound("戏曲碎打铃钹定场05_爱给网_aigei_com.mp3");
}

function setup() {
  createCanvas(1000, 300);
  amp = new p5.Amplitude();
}

function draw() {
  a = mouseX;
  if (a >= 30) {
    background(240,100);
  } else {
    background(235, random(50), random(50), 70);
      fill(128, 0, 0); 
  textSize(30);    
  textStyle(BOLD);  
  text("Boost the fight with a click!", width/2 - 150, height/2); 
  }

  let level = amp.getLevel();
  x = random(0, width);
  y = random(0, height);
  let dia = map(level, 0.0, 1.0, 4, 300);
  circle(x, y, dia);
  fill(255, 0, 255, 70);

  rectMode(CENTER);
  image(img1, 2 * mouseX - a, mouseY, 150, 150);
  image(img2, mouseX + a, mouseY - 30, 180, 180);

  let img1X = 2 * mouseX - a;
  let img1Y = mouseY;
  let img2X = mouseX + a;
  let img2Y = mouseY - 30;

  // circle(width/2 , height/2 + 50, 200);

  triangle(-20, height, 30, random(200, 210), 400, height);
  triangle(300, height, 430, random(200, 210), 700, width);
  triangle(100, height, 330, random(200, 210), 400, height);
  triangle(460, height, 560, random(200, 210), 750, height);
  triangle(580, height, 650, random(200, 210), 800, height);
  triangle(770, height, 730, random(200, 210), 1000, height);
}

function mousePressed() {
  if (song.isPlaying() == false) {
    song.play();
    frameRate(6);
  } else {
    song.pause();
    frameRate(100);
  }
}



